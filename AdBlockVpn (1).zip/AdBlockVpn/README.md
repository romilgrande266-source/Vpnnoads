# AdBlock VPN (Android)

Local VPN na nagba-block ng ads at trackers sa lahat ng apps gamit ang DNS filtering. Walang server, walang external na dependency, at hindi lumalabas ang traffic mo sa ibang tao. DNS queries lang ang dumadaan sa app.

## Paano i-build

1. I-install ang **Android Studio** (https://developer.android.com/studio).
2. I-unzip ang folder na ito, tapos **File → Open** at piliin ang `AdBlockVpn`.
3. Hintayin ang Gradle sync (kailangan ng internet sa unang beses).
4. Para sa APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   Nasa `app/build/outputs/apk/debug/app-debug.apk` ang resulta. Ipasa sa phone at i-install (payagan ang install from unknown sources).
   Puwede ring i-plug ang phone (USB debugging naka-on) at pindutin ang **Run ▶**.

## Walang computer? I-build sa GitHub (phone browser lang)

1. Gumawa ng libreng account sa github.com, tapos **New repository** (puwedeng Private).
2. **Add file → Upload files**, piliin ang `AdBlockVpn.zip`, at **Commit changes**. (Huwag i-extract, zip mismo ang i-upload.)
3. **Add file → Create new file**. Sa pangalan, i-type ang `.github/workflows/build.yml`, i-paste ang laman ng `build.yml`, at **Commit changes**.
4. Buksan ang **Actions** tab at hintayin na matapos ang "Build APK" (mga 3 hanggang 5 minuto).
5. Buksan ang run, bumaba sa **Artifacts**, at i-download ang `app-debug-apk`. Zip ito, kaya i-extract para makuha ang `app-debug.apk`, tapos i-install.

Kung nag-fail, buksan ang run at ipakita sa akin ang error sa pulang step.

## Paano gamitin

1. Buksan ang app, pindutin ang **I-ON ANG ADBLOCK**, at i-accept ang VPN permission.
2. Pindutin ang **I-update ang blocklist** para makuha ang malaking listahan (StevenBlack hosts, ~100k+ na domains). Kailangan ng internet. Maliit lang ang starter list na kasama.
3. Para huminto, pindutin ang **I-OFF**.

## Background running

- Kapag naka-ON, may notification na "Tumatakbo sa background" at hindi ito titigil kahit isara mo ang app. May **I-OFF** button sa mismong notification.
- Awtomatikong bubukas pagka-restart ng phone, basta naka-ON ito bago patayin ang phone.
- Pindutin ang **Payagang tumakbo sa background (battery)** sa app at piliin ang *Allow*. Sa Xiaomi, Oppo, Vivo, Realme at Samsung, i-check din sa Settings → Apps → AdBlock VPN → Battery na naka-*Unrestricted*, at i-enable ang *Autostart* kung mayroon.
- Sa Android 13 pataas, i-allow ang notification permission para makita ang notification.

## Mga limitasyon (importante)

- **Hindi nito ma-block ang YouTube ads.** Galing sa parehong server ang video at ang ad, kaya hindi puwedeng i-block ang isa nang hindi nasisira ang isa. Banner at in-app ads (games, utility apps, websites) ang kaya nito.
- **Private DNS**: i-set sa *Off* o *Automatic* sa Settings → Network. Kapag naka-*Strict* (may hostname), nilalampasan nito ang VPN.
- **Chrome / Firefox**: i-off ang "Use secure DNS" / DNS over HTTPS, kasi nilalampasan din nito ang VPN.
- Apps na may sariling DNS-over-HTTPS ay hindi mahaharang.
- IPv4 UDP DNS lang ang hinahawakan (TCP DNS at IPv6 ay hindi). Sapat ito sa halos lahat ng apps.
- Sa ilang phone (Xiaomi, Oppo, Vivo, Realme) maaaring patayin ng battery saver ang app. Ilagay sa *Unrestricted* ang battery setting ng AdBlock VPN.
- Dahil matching din ang subdomains, may pagkakataong ma-block ang isang lehitimong site. Kapag may app na hindi gumagana, i-OFF muna para i-check.

## Paano ito gumagana

- `AdBlockVpnService` ay gumagawa ng VPN interface na may pekeng DNS server (`10.111.222.2`). Ang ruta papunta lang sa IP na iyon ang dumadaan sa tunnel, kaya normal ang bilis ng lahat ng ibang traffic.
- Binabasa nito ang bawat DNS query (`DnsPacket.kt`). Kapag nasa blocklist (`Blocklist.kt`) ang domain, sinasagot ng `0.0.0.0`. Kapag hindi, ipinapasa sa `1.1.1.1` (o `8.8.8.8` kung walang sagot) at ibinabalik ang sagot.
- Para palitan ang upstream DNS, baguhin ang `UPSTREAM_DNS` sa `AdBlockVpnService.kt`. Para palitan ang pinagkukunan ng blocklist, baguhin ang `LIST_URL` sa `MainActivity.kt`.

## Paalala

Isinulat ang code na ito nang hindi na-compile at hindi pa na-test sa totoong phone. Kung may error sa build o sa pag-run, ipakita lang sa akin ang error message para maayos.
