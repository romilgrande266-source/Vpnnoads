package com.example.adblockvpn

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Listahan ng mga domain na iba-block. Tinatanggap ang 3 format:
 *  - hosts:   0.0.0.0 ads.example.com
 *  - plain:   ads.example.com
 *  - adblock: ||ads.example.com^
 * Pati ang mga subdomain ng nakalistang domain ay iba-block.
 */
object Blocklist {

    private const val ASSET_NAME = "blocklist.txt"
    private const val DOWNLOADED_NAME = "downloaded_blocklist.txt"

    private val IGNORED = setOf(
        "localhost", "localhost.localdomain", "local", "broadcasthost",
        "ip6-localhost", "ip6-loopback", "ip6-localnet", "ip6-mcastprefix",
        "ip6-allnodes", "ip6-allrouters", "ip6-allhosts", "0.0.0.0"
    )
    private val VALID = Regex("^[a-z0-9]([a-z0-9_.-]*[a-z0-9])?$")
    private val WHITESPACE = Regex("\\s+")

    @Volatile
    private var domains: Set<String> = emptySet()

    @Volatile
    private var loaded = false

    val size: Int
        get() = domains.size

    @Synchronized
    fun ensureLoaded(context: Context) {
        if (!loaded) load(context)
    }

    /** Binabasa ang starter list (assets) at ang na-download na list kung mayroon. */
    @Synchronized
    fun load(context: Context) {
        val set = HashSet<String>(200_000)

        context.assets.open(ASSET_NAME).bufferedReader().useLines { lines ->
            lines.forEach { line -> parseLine(line)?.let { set.add(it) } }
        }

        val downloaded = File(context.filesDir, DOWNLOADED_NAME)
        if (downloaded.exists()) {
            downloaded.bufferedReader().useLines { lines ->
                lines.forEach { line -> parseLine(line)?.let { set.add(it) } }
            }
        }

        domains = set
        loaded = true
    }

    fun isBlocked(name: String): Boolean {
        val set = domains
        var d = name.trimEnd('.')
        while (d.isNotEmpty()) {
            if (set.contains(d)) return true
            val dot = d.indexOf('.')
            if (dot < 0) return false
            d = d.substring(dot + 1)
        }
        return false
    }

    /** Dina-download ang list. Blocking ito, kaya tawagin sa background thread. Ibinabalik ang dami ng domains. */
    fun download(context: Context, url: String): Int {
        val tmp = File(context.filesDir, "$DOWNLOADED_NAME.tmp")
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            conn.inputStream.use { input ->
                tmp.outputStream().use { out -> input.copyTo(out) }
            }
        } finally {
            conn.disconnect()
        }

        // Siguraduhing may sapat na laman bago palitan ang lumang list
        var count = 0
        tmp.bufferedReader().useLines { lines ->
            lines.forEach { line -> if (parseLine(line) != null) count++ }
        }
        if (count < 100) {
            tmp.delete()
            throw IOException("Walang laman o mali ang format ng list")
        }

        val target = File(context.filesDir, DOWNLOADED_NAME)
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) throw IOException("Hindi ma-save ang list")

        load(context)
        return size
    }

    private fun parseLine(raw: String): String? {
        var line = raw.trim()
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("!")) return null

        val candidate: String
        if (line.startsWith("||")) {
            // adblock format: ||domain^ (o ||domain^$important)
            val end = line.indexOf('^')
            if (end < 3) return null
            val rest = line.substring(end + 1)
            if (rest.isNotEmpty() && rest != "\$important") return null
            candidate = line.substring(2, end)
        } else {
            val hash = line.indexOf('#')
            if (hash >= 0) line = line.substring(0, hash).trim()
            if (line.isEmpty()) return null
            val parts = line.split(WHITESPACE)
            candidate = when (parts.size) {
                1 -> parts[0]
                2 -> if (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") parts[1] else return null
                else -> return null
            }
        }

        val d = candidate.lowercase().trim('.')
        if (d.isEmpty() || d in IGNORED) return null
        if (!VALID.matches(d)) return null
        if (d.all { it.isDigit() || it == '.' }) return null   // IP address ito, hindi domain
        return d
    }
}
