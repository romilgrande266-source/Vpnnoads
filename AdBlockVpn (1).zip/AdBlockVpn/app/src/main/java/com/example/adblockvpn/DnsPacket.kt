package com.example.adblockvpn

import java.io.ByteArrayOutputStream

/** Maliliit na helper para sa pag-parse ng DNS query at pag-build ng IPv4/UDP packet. */
object DnsPacket {

    class Question(val name: String, val type: Int, val endOffset: Int)

    fun u16(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xFF) shl 8) or (b[off + 1].toInt() and 0xFF)

    fun putU16(b: ByteArray, off: Int, v: Int) {
        b[off] = (v shr 8).toByte()
        b[off + 1] = v.toByte()
    }

    /** Binabasa ang unang question ng DNS query. Null kung hindi standard query o sira ang packet. */
    fun parseQuestion(dns: ByteArray): Question? {
        if (dns.size < 12) return null
        val flags = u16(dns, 2)
        if ((flags and 0x8000) != 0) return null           // response na ito, hindi query
        if (((flags shr 11) and 0xF) != 0) return null     // standard query (opcode 0) lang
        if (u16(dns, 4) < 1) return null                   // walang question

        var pos = 12
        val name = StringBuilder()
        while (true) {
            if (pos >= dns.size) return null
            val len = dns[pos].toInt() and 0xFF
            if (len == 0) {
                pos++
                break
            }
            if ((len and 0xC0) != 0) return null           // walang compression sa question ng query
            if (pos + 1 + len > dns.size) return null
            if (name.isNotEmpty()) name.append('.')
            for (i in 1..len) name.append((dns[pos + i].toInt() and 0xFF).toChar())
            pos += 1 + len
        }
        if (pos + 4 > dns.size) return null                // kailangan ng QTYPE at QCLASS
        return Question(name.toString().lowercase(), u16(dns, pos), pos + 4)
    }

    /**
     * Sagot para sa na-block na domain: A -> 0.0.0.0, AAAA -> ::, iba pang type -> walang sagot (NODATA).
     */
    fun buildBlockedResponse(query: ByteArray, q: Question): ByteArray {
        val rdata: ByteArray? = when (q.type) {
            1 -> ByteArray(4)       // A
            28 -> ByteArray(16)     // AAAA
            else -> null
        }

        val out = ByteArrayOutputStream()
        out.write(query, 0, 2)                                         // ID
        val flags = 0x8000 or (u16(query, 2) and 0x7900) or 0x0080     // QR, kopya ang opcode at RD, RA
        out.write(flags shr 8)
        out.write(flags and 0xFF)
        out.write(0); out.write(1)                                     // QDCOUNT
        out.write(0); out.write(if (rdata != null) 1 else 0)           // ANCOUNT
        out.write(0); out.write(0)                                     // NSCOUNT
        out.write(0); out.write(0)                                     // ARCOUNT
        out.write(query, 12, q.endOffset - 12)                         // question section

        if (rdata != null) {
            out.write(0xC0); out.write(0x0C)                           // pointer sa pangalan sa question
            out.write(0); out.write(q.type)                            // TYPE
            out.write(0); out.write(1)                                 // CLASS IN
            out.write(0); out.write(0); out.write(0); out.write(60)    // TTL: 60 segundo
            out.write(0); out.write(rdata.size)                        // RDLENGTH
            out.write(rdata, 0, rdata.size)
        }
        return out.toByteArray()
    }

    /** Binubuo ang buong IPv4 + UDP packet na maisusulat pabalik sa tunnel. */
    fun buildUdpIpv4(
        src: ByteArray,
        dst: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val total = 20 + 8 + payload.size
        val p = ByteArray(total)
        p[0] = 0x45                       // IPv4, header na 20 bytes
        putU16(p, 2, total)
        p[6] = 0x40                       // Don't Fragment
        p[8] = 64                         // TTL
        p[9] = 17                         // UDP
        System.arraycopy(src, 0, p, 12, 4)
        System.arraycopy(dst, 0, p, 16, 4)
        putU16(p, 10, ipChecksum(p, 20))

        putU16(p, 20, srcPort)
        putU16(p, 22, dstPort)
        putU16(p, 24, 8 + payload.size)
        // UDP checksum na 0 ay pinapayagan sa IPv4
        System.arraycopy(payload, 0, p, 28, payload.size)
        return p
    }

    private fun ipChecksum(b: ByteArray, len: Int): Int {
        var sum = 0
        var i = 0
        while (i < len) {
            sum += u16(b, i)
            i += 2
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }
}
