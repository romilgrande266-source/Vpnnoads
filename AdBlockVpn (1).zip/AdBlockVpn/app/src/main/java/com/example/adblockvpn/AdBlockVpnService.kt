package com.example.adblockvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicLong

/**
 * Local VPN na DNS lang ang dinadaanan. Paano gumagana:
 *  1. Sinasabi natin sa Android na ang DNS server ay isang pekeng IP (10.111.222.2) at ruta lang
 *     papunta roon ang dadaan sa tunnel. Ibig sabihin, normal pa rin ang takbo ng ibang traffic.
 *  2. Binabasa natin ang bawat DNS query. Kapag nasa blocklist ang domain, sinasagot natin ng 0.0.0.0.
 *  3. Kapag hindi, ipinapasa natin sa totoong DNS (1.1.1.1 / 8.8.8.8) at ibinabalik ang sagot.
 *
 * Tumatakbo ito bilang foreground service (may notification) para hindi patayin ng Android sa background.
 */
class AdBlockVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.example.adblockvpn.START"
        const val ACTION_STOP = "com.example.adblockvpn.STOP"
        private const val TAG = "AdBlockVpn"

        private const val CHANNEL_ID = "adblock_status"
        private const val NOTIFICATION_ID = 1

        private const val PREFS = "adblock_prefs"
        private const val KEY_ENABLED = "enabled"

        private const val VPN_ADDRESS = "10.111.222.1"
        private const val FAKE_DNS = "10.111.222.2"
        private val UPSTREAM_DNS = listOf("1.1.1.1", "8.8.8.8")

        @Volatile
        var isRunning = false
        val totalQueries = AtomicLong(0)
        val blockedQueries = AtomicLong(0)

        /** Naaalala kung naka-ON ba ang user, para sa auto-start pagka-restart ng phone. */
        fun isEnabled(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

        fun setEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply()
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private var executor: ExecutorService? = null

    @Volatile
    private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            setEnabled(this, false)
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }

        // Kailangang tawagin agad pagkatapos ng startForegroundService
        goForeground()
        setEnabled(this, true)
        startVpn()
        return START_STICKY
    }

    override fun onRevoke() {
        // Ibang VPN app ang pumalit o inalis ng user ang permission
        setEnabled(this, false)
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    private fun goForeground() {
        val notification = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Hindi ma-start ang foreground mode", e)
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notif_channel),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AdBlockVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        @Suppress("DEPRECATION")
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_launcher),
                    getString(R.string.btn_stop),
                    stop
                ).build()
            )
            .build()
    }

    @Synchronized
    private fun startVpn() {
        if (running) return
        Blocklist.ensureLoaded(applicationContext)

        val pfd = try {
            Builder()
                .setSession("AdBlock")
                .setBlocking(true)
                .setMtu(1500)
                .addAddress(VPN_ADDRESS, 32)
                .addDnsServer(FAKE_DNS)
                .addRoute(FAKE_DNS, 32)
                .establish()
        } catch (e: Exception) {
            Log.e(TAG, "Hindi ma-establish ang VPN", e)
            null
        }
        if (pfd == null) {
            // Walang pahintulot o may problema, kaya huwag nang subukan ulit pagka-boot
            setEnabled(this, false)
            stopVpn()
            stopSelf()
            return
        }

        tun = pfd
        totalQueries.set(0)
        blockedQueries.set(0)
        running = true
        isRunning = true
        executor = Executors.newFixedThreadPool(8)
        worker = Thread({ runLoop(pfd) }, "AdBlockVpn-loop").also { it.start() }
    }

    @Synchronized
    private fun stopVpn() {
        running = false
        isRunning = false
        executor?.shutdownNow()
        executor = null
        try {
            tun?.close()
        } catch (e: IOException) {
            // wala na tayong magagawa
        }
        tun = null
        worker?.interrupt()
        worker = null
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
            // hindi pa naka-foreground
        }
    }

    private fun runLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (running) {
                val len = input.read(buf)
                if (len < 0) break
                if (len > 0) handlePacket(buf, len, output)
            }
        } catch (e: IOException) {
            if (running) Log.w(TAG, "Tumigil ang tunnel", e)
        } finally {
            if (running) {
                // Hindi sinadya ang pagtigil, kaya linisin natin
                stopVpn()
                stopSelf()
            }
        }
    }

    private fun handlePacket(buf: ByteArray, len: Int, output: FileOutputStream) {
        if (len < 28) return
        if (((buf[0].toInt() shr 4) and 0xF) != 4) return          // IPv4 lang
        val ihl = (buf[0].toInt() and 0xF) * 4
        if (ihl < 20 || len < ihl + 8) return
        if ((buf[9].toInt() and 0xFF) != 17) return                 // UDP lang

        val srcPort = DnsPacket.u16(buf, ihl)
        val dstPort = DnsPacket.u16(buf, ihl + 2)
        if (dstPort != 53) return

        val udpLen = DnsPacket.u16(buf, ihl + 4)
        val dnsLen = minOf(udpLen - 8, len - ihl - 8)
        if (dnsLen < 12) return

        // Kopyahin dahil ginagamit ulit ang buf sa susunod na basa
        val srcIp = buf.copyOfRange(12, 16)
        val dstIp = buf.copyOfRange(16, 20)
        val dns = buf.copyOfRange(ihl + 8, ihl + 8 + dnsLen)

        try {
            executor?.execute { answer(output, srcIp, dstIp, srcPort, dstPort, dns) }
        } catch (e: RejectedExecutionException) {
            // patay na ang service
        }
    }

    private fun answer(
        output: FileOutputStream,
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        dns: ByteArray
    ) {
        totalQueries.incrementAndGet()
        val q = DnsPacket.parseQuestion(dns)

        val reply: ByteArray? = if (q != null && Blocklist.isBlocked(q.name)) {
            blockedQueries.incrementAndGet()
            DnsPacket.buildBlockedResponse(dns, q)
        } else {
            forward(dns)
        }
        if (reply == null) return

        // Baliktad ang source at destination dahil sagot ito
        val packet = DnsPacket.buildUdpIpv4(dstIp, srcIp, dstPort, srcPort, reply)
        synchronized(output) {
            try {
                output.write(packet)
            } catch (e: IOException) {
                // sarado na ang tunnel
            }
        }
    }

    /** Ipinapasa ang query sa totoong DNS server. Subukan ang susunod kung walang sagot. */
    private fun forward(dns: ByteArray): ByteArray? {
        for (server in UPSTREAM_DNS) {
            val socket = DatagramSocket()
            try {
                protect(socket)   // para hindi bumalik sa VPN ang packet
                socket.soTimeout = 3000
                socket.connect(InetAddress.getByName(server), 53)
                socket.send(DatagramPacket(dns, dns.size))
                val buf = ByteArray(4096)
                val resp = DatagramPacket(buf, buf.size)
                socket.receive(resp)
                return buf.copyOf(resp.length)
            } catch (e: IOException) {
                Log.d(TAG, "Walang sagot mula sa $server")
            } finally {
                socket.close()
            }
        }
        return null
    }
}
