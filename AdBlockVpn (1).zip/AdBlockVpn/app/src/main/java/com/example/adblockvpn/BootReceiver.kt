package com.example.adblockvpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build

/** Awtomatikong binubuksan ang AdBlock pagka-restart ng phone, kung naka-ON ito bago patayin ang phone. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!AdBlockVpnService.isEnabled(context)) return
        // Kapag hindi null, kailangan ulit ng pahintulot ng user kaya hindi puwedeng awtomatiko
        if (VpnService.prepare(context) != null) return

        val start = Intent(context, AdBlockVpnService::class.java)
            .setAction(AdBlockVpnService.ACTION_START)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(start)
            } else {
                context.startService(start)
            }
        } catch (e: Exception) {
            // pinigilan ng system ang pag-start, subukan na lang ulit kapag binuksan ang app
        }
    }
}
