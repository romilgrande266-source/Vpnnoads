package com.example.adblockvpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicLong

/**
 * Local VPN na DNS lang ang dinadaanan. Paano gumagana:
 *  1. Sinasabi natin sa Android na ang DNS server ay isang pekeng IP (10.111.222.2) at ruta lang
 *     papunta roon ang dadaan sa tunnel. Ibig sabihin, normal pa rin ang takbo ng ibang traffic.
 *  2. Binabasa natin ang bawat DNS query. Kapag nasa blocklist ang domain, sinasagot natin ng 0.0.0.0.
 *  3. Kapag hindi, ipinapasa natin sa totoong DNS (1.1.1.1 / 8.8.8.8) at ibinabalik ang sagot.
 */
class AdBlockVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.example.adblockvpn.START"
        const val ACTION_STOP = "com.example.adblockvpn.STOP"
        private const val TAG = "AdBlockVpn"

        private const val VPN_ADDRESS = "10.111.222.1"
        private const val FAKE_DNS = "10.111.222.2"
        private val UPSTREAM_DNS = listOf("1.1.1.1", "8.8.8.8")

        @Volatile
        var isRunning = false
        val totalQueries = AtomicLong(0)
        val blockedQueries = AtomicLong(0)
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private var executor: ExecutorService? = null

    @Volatile
    private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        startVpn()
        return START_STICKY
    }

    override fun onRevoke() {
        // Ibang VPN app ang pumalit o inalis ang permission
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    @Synchronized
    private fun startVpn() {
        if (running) return
        Blocklist.ensureLoaded(applicationContext)

        val pfd = try {
            Builder()
                .setSession("AdBlock")
                .setBlocking(true)
                .setMtu(1500)
                .addAddress(VPN_ADDRESS, 32)
                .addDnsServer(FAKE_DNS)
                .addRoute(FAKE_DNS, 32)
                .establish()
        } catch (e: Exception) {
            Log.e(TAG, "Hindi ma-establish ang VPN", e)
            null
        }
        if (pfd == null) {
            stopSelf()
            return
        }

        tun = pfd
        totalQueries.set(0)
        blockedQueries.set(0)
        running = true
        isRunning = true
        executor = Executors.newFixedThreadPool(8)
        worker = Thread({ runLoop(pfd) }, "AdBlockVpn-loop").also { it.start() }
    }

    @Synchronized
    private fun stopVpn() {
        running = false
        isRunning = false
        executor?.shutdownNow()
        executor = null
        try {
            tun?.close()
        } catch (e: IOException) {
            // wala na tayong magagawa
        }
        tun = null
        worker?.interrupt()
        worker = null
    }

    private fun runLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (running) {
                val len = input.read(buf)
                if (len < 0) break
                if (len > 0) handlePacket(buf, len, output)
            }
        } catch (e: IOException) {
            if (running) Log.w(TAG, "Tumigil ang tunnel", e)
        } finally {
            if (running) {
                // Hindi sinadya ang pagtigil, kaya linisin natin
                stopVpn()
                stopSelf()
            }
        }
    }

    private fun handlePacket(buf: ByteArray, len: Int, output: FileOutputStream) {
        if (len < 28) return
        if (((buf[0].toInt() shr 4) and 0xF) != 4) return          // IPv4 lang
        val ihl = (buf[0].toInt() and 0xF) * 4
        if (ihl < 20 || len < ihl + 8) return
        if ((buf[9].toInt() and 0xFF) != 17) return                 // UDP lang

        val srcPort = DnsPacket.u16(buf, ihl)
        val dstPort = DnsPacket.u16(buf, ihl + 2)
        if (dstPort != 53) return

        val udpLen = DnsPacket.u16(buf, ihl + 4)
        val dnsLen = minOf(udpLen - 8, len - ihl - 8)
        if (dnsLen < 12) return

        // Kopyahin dahil ginagamit ulit ang buf sa susunod na basa
        val srcIp = buf.copyOfRange(12, 16)
        val dstIp = buf.copyOfRange(16, 20)
        val dns = buf.copyOfRange(ihl + 8, ihl + 8 + dnsLen)

        try {
            executor?.execute { answer(output, srcIp, dstIp, srcPort, dstPort, dns) }
        } catch (e: RejectedExecutionException) {
            // patay na ang service
        }
    }

    private fun answer(
        output: FileOutputStream,
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        dns: ByteArray
    ) {
        totalQueries.incrementAndGet()
        val q = DnsPacket.parseQuestion(dns)

        val reply: ByteArray? = if (q != null && Blocklist.isBlocked(q.name)) {
            blockedQueries.incrementAndGet()
            DnsPacket.buildBlockedResponse(dns, q)
        } else {
            forward(dns)
        }
        if (reply == null) return

        // Baliktad ang source at destination dahil sagot ito
        val packet = DnsPacket.buildUdpIpv4(dstIp, srcIp, dstPort, srcPort, reply)
        synchronized(output) {
            try {
                output.write(packet)
            } catch (e: IOException) {
                // sarado na ang tunnel
            }
        }
    }

    /** Ipinapasa ang query sa totoong DNS server. Subukan ang susunod kung walang sagot. */
    private fun forward(dns: ByteArray): ByteArray? {
        for (server in UPSTREAM_DNS) {
            val socket = DatagramSocket()
            try {
                protect(socket)   // para hindi bumalik sa VPN ang packet
                socket.soTimeout = 3000
                socket.connect(InetAddress.getByName(server), 53)
                socket.send(DatagramPacket(dns, dns.size))
                val buf = ByteArray(4096)
                val resp = DatagramPacket(buf, buf.size)
                socket.receive(resp)
                return buf.copyOf(resp.length)
            } catch (e: IOException) {
                Log.d(TAG, "Walang sagot mula sa $server")
            } finally {
                socket.close()
            }
        }
        return null
    }
}
