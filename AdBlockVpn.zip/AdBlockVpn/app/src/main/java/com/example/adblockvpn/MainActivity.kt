package com.example.adblockvpn

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private companion object {
        const val REQ_VPN = 1
        const val LIST_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
    }

    private lateinit var statusText: TextView
    private lateinit var statsText: TextView
    private lateinit var toggleButton: Button
    private lateinit var updateButton: Button

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refreshUi()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        statsText = findViewById(R.id.statsText)
        toggleButton = findViewById(R.id.toggleButton)
        updateButton = findViewById(R.id.updateButton)

        toggleButton.setOnClickListener {
            if (AdBlockVpnService.isRunning) stopVpn() else startVpn()
        }
        updateButton.setOnClickListener { updateBlocklist() }

        // I-load ang blocklist sa background para lumabas agad ang bilang
        Thread {
            Blocklist.ensureLoaded(applicationContext)
            runOnUiThread { refreshUi() }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun startVpn() {
        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(permissionIntent, REQ_VPN)
        } else {
            launchService(AdBlockVpnService.ACTION_START)
        }
    }

    private fun stopVpn() {
        launchService(AdBlockVpnService.ACTION_STOP)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) {
            launchService(AdBlockVpnService.ACTION_START)
        }
    }

    private fun launchService(action: String) {
        startService(Intent(this, AdBlockVpnService::class.java).setAction(action))
    }

    private fun updateBlocklist() {
        updateButton.isEnabled = false
        updateButton.text = getString(R.string.btn_updating)
        Thread {
            val message = try {
                val count = Blocklist.download(applicationContext, LIST_URL)
                getString(R.string.updated, count)
            } catch (e: Exception) {
                getString(R.string.update_failed, e.message ?: e.javaClass.simpleName)
            }
            runOnUiThread {
                updateButton.isEnabled = true
                updateButton.text = getString(R.string.btn_update)
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                refreshUi()
            }
        }.start()
    }

    private fun refreshUi() {
        val on = AdBlockVpnService.isRunning
        statusText.text = getString(if (on) R.string.status_on else R.string.status_off)
        statusText.setTextColor(Color.parseColor(if (on) "#2E7D32" else "#C62828"))
        toggleButton.text = getString(if (on) R.string.btn_stop else R.string.btn_start)
        statsText.text = getString(
            R.string.stats,
            AdBlockVpnService.blockedQueries.get(),
            AdBlockVpnService.totalQueries.get(),
            Blocklist.size
        )
    }
}
